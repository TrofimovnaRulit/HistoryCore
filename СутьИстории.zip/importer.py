#!/usr/bin/env python3
"""Convenient entry point for the textbook JSON importer."""
from scripts.build_history_json import main

if __name__ == "__main__":
    raise SystemExit(main())
