'use strict';
const app = document.querySelector('#app');
const state = {grades: [], subjects: [], paragraphs: [], grade: 6, subject: 'russian_history', paragraph: '', mode: 'normal', summary: null, attempt: null, question: 0, busy: false};
const modeNames = {short: 'Очень кратко', normal: 'Обычный пересказ', detailed: 'Подробно'};
const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const e = escapeHTML;
let requestVersion = 0;
let noticeTimer;
function notify(message) { const box = document.querySelector('#notice'); box.textContent = message; box.hidden = false; clearTimeout(noticeTimer); noticeTimer = setTimeout(() => {box.hidden = true;}, 6500); }
async function api(path, data) {
  const options = {credentials: 'same-origin', headers: {Accept: 'application/json'}};
  if (data !== undefined) {
    options.method = 'POST';
    options.headers['Content-Type'] = 'application/json';
    options.headers['X-CSRFToken'] = decodeURIComponent(document.cookie.split('; ').find(x => x.startsWith('csrftoken='))?.split('=')[1] || '');
    options.body = JSON.stringify(data);
  }
  let response;
  try { response = await fetch('/api/' + path, options); }
  catch { throw new Error('Не удалось связаться с сервером. Проверьте подключение и попробуйте ещё раз.'); }
  let result;
  try { result = await response.json(); } catch { throw new Error('Сервис временно недоступен. Попробуйте ещё раз.'); }
  if (!response.ok) {
    const error = new Error(typeof result.detail === 'string' ? result.detail : 'Не удалось выполнить запрос. Проверьте выбор и попробуйте снова.');
    error.status = response.status; error.data = result; throw error;
  }
  return result;
}
function mount(html) { app.innerHTML = html; }
function focusPage() { app.focus({preventScroll:true}); window.scrollTo({top:0, behavior:'instant'}); }
function loading(title, subtitle) {
  mount(`<section class="loading-card view-enter" role="status" aria-live="polite"><span class="spinner"></span><h2>${e(title)}</h2><p>${e(subtitle)}</p><div class="skeleton-group" aria-hidden="true"><div class="skeleton"></div><div class="skeleton"></div><div class="skeleton short"></div><div class="skeleton"></div><div class="skeleton short"></div></div></section>`);
}
function options(items, selected, empty) { return `<option value="">${e(empty)}</option>` + items.map(x => `<option value="${e(x.id)}" ${String(selected) === String(x.id) ? 'selected' : ''}>${e(x.title)}</option>`).join(''); }
function renderHome() {
  const para = state.paragraphs.find(x => x.id == state.paragraph);
  mount(`<div class="view-enter"><section class="hero"><div><div class="eyebrow"><span class="dash"></span>История становится понятной</div><h1>Понять.<br><span>А не зазубрить.</span></h1><p>Выбери класс и параграф — получи понятный пересказ. А потом проверь, что запомнилось.</p></div><div class="hero-route" aria-label="Как это работает"><div class="route-item"><span class="route-num">01</span><div><strong>Выбери свою тему</strong><small>От класса до нужного параграфа</small></div></div><div class="route-item"><span class="route-num">02</span><div><strong>Разберись в событиях</strong><small>Пересказ в удобном тебе объёме</small></div></div><div class="route-item"><span class="route-num">03</span><div><strong>Проверь себя</strong><small>Тест по прочитанному пересказу</small></div></div></div></section>
  <div class="workspace"><section class="panel selection-panel" id="selection"><div class="section-heading"><h2>Что будем изучать?</h2><span class="small-label">Твоя точка старта</span></div>
  <div class="step-title"><span class="step-number">1</span>Выбери класс</div><div class="grades" role="group" aria-label="Класс">${state.grades.map(x => `<button class="grade ${x.id === state.grade ? 'selected' : ''}" data-grade="${x.id}" aria-pressed="${x.id === state.grade}">${x.id}<small>класс</small></button>`).join('')}</div>
  <div class="step-title"><span class="step-number">2</span>Какую историю?</div><div class="subjects" role="group" aria-label="Предмет">${state.subjects.map(x => `<button class="subject ${x.slug === state.subject ? 'selected' : ''}" data-subject="${e(x.slug)}" aria-pressed="${x.slug === state.subject}"><span class="subject-symbol" aria-hidden="true">${x.slug === 'russian_history' ? '⌂' : '◎'}</span>${e(x.title)}</button>`).join('')}</div>
  <div class="step-title"><span class="step-number">3</span>Выбери параграф</div><div class="paragraph-list" role="group" aria-label="Параграф">${state.paragraphs.length ? state.paragraphs.map(x => `<button class="paragraph-card ${x.id == state.paragraph ? 'selected' : ''}" data-paragraph="${x.id}" aria-pressed="${x.id == state.paragraph}"><span class="para-number">§ ${e(x.number)}</span><strong>${e(x.title)}</strong><span class="radio-dot" aria-hidden="true"></span></button>`).join('') : `<div class="empty-state"><strong>Выбери класс и историю</strong>Доступные параграфы появятся здесь.</div>`}</div>
  <div class="step-title"><span class="step-number">4</span>Сколько подробностей?</div><div class="modes" role="group" aria-label="Формат пересказа">${Object.entries(modeNames).map(([key,name]) => `<button class="mode ${state.mode === key ? 'selected' : ''}" data-mode="${key}" aria-pressed="${state.mode === key}"><strong>${name}</strong><span>${{short:'Повторить главное',normal:'Разобраться в теме',detailed:'Погрузиться глубже'}[key]}</span></button>`).join('')}</div>
  <button class="button primary full" data-action="generate" ${!para ? 'disabled' : ''}>Создать пересказ <span class="arrow" aria-hidden="true">↗</span></button></section>
  <aside class="panel side-card"><span class="tag">Всё по твоей теме</span><h3>${para ? e(para.title) : 'Большая история — по частям'}</h3><p>${para ? `§ ${e(para.number)} · ${state.grade} класс<br>Выбирай удобный объём и начинай.` : 'Сначала один параграф. Потом — целая картина событий.'}</p><div class="journey"><div class="journey-row"><span class="icon" aria-hidden="true">≋</span><div><strong>Понятный пересказ</strong><small>Без сложных формулировок</small></div></div><div class="journey-row"><span class="icon" aria-hidden="true">◷</span><div><strong>В твоём темпе</strong><small>Кратко или с подробностями</small></div></div><div class="journey-row"><span class="icon" aria-hidden="true">✓</span><div><strong>Тест по прочитанному</strong><small>Чтобы знания остались</small></div></div></div><div class="side-bottom"><span aria-hidden="true">✳</span>Меньше зубрёжки. Больше смысла.</div></aside></div></div>`);
}
async function loadCatalog(level = 'books') {
  const version = ++requestVersion;
  state.paragraphs=[];state.paragraph='';
  renderHome();
  const holder = app.querySelector('.paragraph-list');
  holder.innerHTML = '<div class="empty-state" role="status"><span class="spinner"></span><div>Ищем материалы…</div></div>';
  try {
    const items = await api(`paragraphs/?grade=${state.grade}&subject=${encodeURIComponent(state.subject)}`);
    if (version !== requestVersion) return;
    state.paragraphs=items;
    renderHome();
  } catch(error) {if (version === requestVersion) {renderHome();notify(error.message);}}
}
function prose(text) {
  return text.split(/\n\s*\n/).map(p => /^#{1,3}\s/.test(p) ? `<h3>${e(p.replace(/^#{1,3}\s/,''))}</h3>` : `<p>${e(p).replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/\n/g,'<br>')}</p>`).join('');
}
function renderSummary() {
  const s=state.summary;
  mount(`<div class="view-enter"><div class="page-top"><button class="button text" data-action="home">← Выбрать другой параграф</button></div><div class="summary-layout"><article class="panel reading-card"><div class="reading-meta"><span class="chip blue">Твой пересказ</span><span class="chip">${e(modeNames[s.mode])}</span></div><h1>${e(s.paragraph.title)}</h1><div class="reading-sub">§ ${e(s.paragraph.number)} · ${e(s.grade)} класс · ${e(s.subject)} · ${Math.max(1,Math.ceil(s.content.split(/\s+/).length/160))} мин чтения</div><div class="prose">${prose(s.content)}</div><div class="reading-end"><span>Хочется другого объяснения?</span><button class="button secondary" data-action="regenerate">↻ Создать другую версию</button></div></article><aside><div class="test-invite"><div class="invite-line"></div><span class="overline">Следующий шаг</span><h2>Прочитал?<br>Проверь себя.</h2><p>Вопросы только по этому пересказу. Посмотри, что запомнилось, а к чему стоит вернуться.</p><button class="button lime" data-action="start-test">Пройти тест <span class="arrow" aria-hidden="true">↗</span></button><small>Без таймера. В своём темпе.</small></div><p class="side-help">Можно возвращаться к вопросам и менять ответы. Результат появится после завершения теста.</p></aside></div></div>`);
}
async function generateSummary(regenerate = false) {
  const paragraph_id = regenerate ? state.summary.paragraph.id : Number(state.paragraph);
  const mode = regenerate ? state.summary.mode : state.mode;
  state.busy=true; loading('Готовим пересказ…','Собираем главное и объясняем сложные моменты.');focusPage();
  try {
    const result = await api(`summaries/${regenerate ? 'regenerate' : 'generate'}/`,{paragraph_id,mode});
    state.summary=result;
    location.hash=`summary/${result.id}`;
    renderSummary();
  } catch(error) {regenerate ? renderSummary() : renderHome();notify(error.message);}
  finally {state.busy=false;}
}
async function startTest() {
  state.busy=true;loading('Готовим вопросы…','Только по тому пересказу, который ты только что прочитал.');focusPage();
  try {const result=await api('tests/generate/',{summary_id:state.summary.id});location.hash=`test/${result.attempt_id}`;}
  catch(error){renderSummary();notify(error.message);}
  finally{state.busy=false;}
}
function renderTest() {
  const a=state.attempt,q=a.questions[state.question],count=a.questions.length,answered=a.questions.filter(q=>q.selected_option!==null).length;
  mount(`<div class="view-enter"><div class="page-top"><button class="button text" data-action="back-summary">← К пересказу</button></div><div class="quiz-layout"><aside class="panel quiz-sidebar"><span class="small-label">Проверяем знания</span><h3>${e(a.title)}</h3><nav class="question-nav" aria-label="Вопросы теста">${a.questions.map((item,i)=>`<button class="${item.selected_option!==null?'answered ':''}${i===state.question?'current':''}" data-question="${i}" aria-label="Вопрос ${i+1}${item.selected_option!==null?', есть ответ':''}" ${i===state.question?'aria-current="step"':''}>${i+1}</button>`).join('')}</nav><p class="nav-legend">Отмеченные номера — вопросы с ответом. К любому можно вернуться.</p></aside><section class="panel quiz-card"><div class="quiz-topline"><strong>Вопрос ${state.question+1} из ${count}</strong><span>${answered} / ${count} отвечено</span></div><div class="progress-track" role="progressbar" aria-label="Ответы" aria-valuemin="0" aria-valuemax="${count}" aria-valuenow="${answered}"><div class="progress-fill" style="width:${answered/count*100}%"></div></div><div class="question-content view-enter"><h1>${e(q.question)}</h1><div class="answer-list" role="group" aria-label="Варианты ответа">${q.options.map((o,i)=>`<button class="answer ${q.selected_option===o.id?'selected':''}" data-option="${o.id}" aria-pressed="${q.selected_option===o.id}"><span class="answer-letter">${'АБВГ'[i]}</span><span>${e(o.text)}</span><span class="radio-dot" aria-hidden="true"></span></button>`).join('')}</div></div><div class="save-status" aria-live="polite">${q.selected_option!==null?'Ответ сохранён':'Выбери один ответ'}</div><div class="quiz-controls"><button class="button secondary" data-action="previous" ${state.question===0?'disabled':''}>← Назад</button>${state.question<count-1?'<button class="button primary" data-action="next">Дальше →</button>':'<button class="button primary" data-action="complete">Завершить ✓</button>'}</div></section></div></div>`);
}
async function saveAnswer(option) {
  const question=state.attempt.questions[state.question];state.busy=true;
  app.querySelectorAll('button').forEach(b=>b.disabled=true);
  app.querySelector('.save-status').textContent='Сохраняем…';
  try {await api(`attempts/${state.attempt.id}/answers/`,{question_id:question.id,option_id:Number(option)});question.selected_option=Number(option);}
  catch(error){notify(error.message);}
  finally{state.busy=false;renderTest();app.querySelector(`[data-option="${option}"]`)?.focus({preventScroll:true});}
}
async function complete(confirm = false) {
  state.busy=true;
  app.querySelectorAll('button').forEach(b=>b.disabled=true);
  try{await api(`attempts/${state.attempt.id}/complete/`,{confirm_incomplete:confirm});location.hash=`result/${state.attempt.id}`;}
  catch(error){renderTest();if(error.status===409 && error.data.unanswered){document.querySelector('#confirm-dialog').showModal();}else notify(error.message);}
  finally{state.busy=false;}
}
function renderResult(r) {
  mount(`<div class="view-enter"><div class="page-top"><span class="breadcrumb">Тест завершён <span>/</span> ${e(r.title)}</span></div><section class="result-hero"><div class="result-ring" style="--score:${r.percentage}%" role="img" aria-label="${r.percentage}% правильных ответов"><div class="ring-value">${r.percentage}%<small>правильных ответов</small></div></div><div class="result-copy"><div class="eyebrow">Твой результат</div><h1>${r.score} из ${r.total} — ${r.percentage>=80?'отличная работа':r.percentage>=50?'хорошее начало':'продолжаем разбираться'}</h1><p>${r.percentage>=80?'Материал усвоен хорошо. Посмотри ответы — и можно двигаться дальше.':'Стоит ещё раз посмотреть пересказ и повторить основные события. Разбор ниже поможет найти нужные моменты.'}</p><div class="result-actions"><button class="button lime" data-action="back-summary">Вернуться к пересказу ↗</button><button class="button secondary" data-action="retry">Пройти ещё раз ↻</button></div></div></section><div class="review-heading"><h2>Разбор ответов</h2><span>Можно спокойно всё проверить</span></div><div class="review-list">${r.questions.map((q,i)=>`<article class="panel review-card"><div class="review-question"><span class="review-status ${q.is_correct?'':'wrong'}" aria-label="${q.is_correct?'Верно':'Неверно'}">${q.is_correct?'✓':'×'}</span><h3>${i+1}. ${e(q.question)}</h3></div><div class="review-answers"><p class="${q.is_correct?'correct-text':'wrong-text'}">Твой ответ: ${q.selected_option===null?'Нет ответа':e(q.options.find(o=>o.id===q.selected_option)?.text)}</p>${q.is_correct?'':`<p class="correct-text">Правильный ответ: ${e(q.options.find(o=>o.id===q.correct_option)?.text)}</p>`}</div></article>`).join('')}</div></div>`);
}
async function route() {
  const match=location.hash.match(/^#(summary|test|result)\/([\w-]+)$/);
  ++requestVersion;
  if(!match){renderHome();focusPage();return;}
  const [,kind,id]=match;
  const currentHash=location.hash;
  try {
    if(kind==='summary') {
      if(String(state.summary?.id)!==id){loading('Открываем пересказ…','Возвращаемся к твоей теме.');state.summary=await api(`summaries/${id}/`);}
      if(location.hash!==currentHash)return;
      renderSummary();
    } else if(kind==='test') {
      loading('Открываем тест…','Сохранённые ответы останутся на месте.');
      const attempt=await api(`attempts/${id}/`);if(location.hash!==currentHash)return;
      state.attempt=attempt;state.question=0;
      if(attempt.completed){location.hash=`result/${id}`;return;}
      renderTest();
    } else {
      loading('Смотрим результат…','Проверяем сохранённые ответы.');
      const result=await api(`attempts/${id}/result/`);if(location.hash!==currentHash)return;
      state.attempt=result;renderResult(result);
    }
    focusPage();
  } catch(error){mount(`<section class="panel error-page"><span class="dialog-symbol" style="margin:auto">!</span><h1>Не удалось открыть страницу</h1><p>${e(error.message)}</p><button class="button primary" data-action="home">К учебникам</button></section>`);}
}
app.addEventListener('click',async event=>{
  const b=event.target.closest('button');if(!b||b.disabled||state.busy)return;
  if(b.dataset.grade){state.grade=Number(b.dataset.grade);await loadCatalog();return;}
  if(b.dataset.subject){state.subject=b.dataset.subject;await loadCatalog();return;}
  if(b.dataset.paragraph){state.paragraph=Number(b.dataset.paragraph);renderHome();app.querySelector(`[data-paragraph="${state.paragraph}"]`)?.focus({preventScroll:true});return;}
  if(b.dataset.mode){state.mode=b.dataset.mode;renderHome();app.querySelector(`[data-mode="${state.mode}"]`)?.focus({preventScroll:true});return;}
  if(b.dataset.question!==undefined){state.question=Number(b.dataset.question);renderTest();return;}
  if(b.dataset.option){await saveAnswer(b.dataset.option);return;}
  switch(b.dataset.action){
    case 'home': location.hash='';renderHome();break;
    case 'generate': await generateSummary();break;
    case 'regenerate': await generateSummary(true);break;
    case 'start-test': await startTest();break;
    case 'back-summary': location.hash=`summary/${state.attempt.test_summary_id||state.attempt.summary_id}`;break;
    case 'previous': state.question--;renderTest();break;
    case 'next': state.question++;renderTest();break;
    case 'complete': await complete();break;
    case 'retry':
      state.busy=true;b.disabled=true;
      try {const r=await api(`attempts/${state.attempt.id}/retry/`,{});location.hash=`test/${r.attempt_id}`;}
      catch(error){notify(error.message);b.disabled=false;}
      finally{state.busy=false;}
      break;
  }
});
document.querySelector('#keep-answering').onclick=()=>document.querySelector('#confirm-dialog').close();
document.querySelector('#finish-anyway').onclick=()=>{document.querySelector('#confirm-dialog').close();complete(true);};
window.addEventListener('hashchange',route);
async function init(){
  try{
    [state.grades,state.subjects]=await Promise.all([api('grades/'),api('subjects/')]);
    if(location.hash) await route();else await loadCatalog();
  }catch(error){mount(`<section class="panel error-page"><h1>Библиотека пока недоступна</h1><p>${e(error.message)}</p><button class="button primary" onclick="location.reload()">Попробовать снова</button></section>`);}
}
init();
