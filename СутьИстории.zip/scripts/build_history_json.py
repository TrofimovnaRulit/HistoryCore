#!/usr/bin/env python3
"""Convert authorized textbook PDFs into private HistoryCore JSON files."""
from __future__ import annotations

import argparse, hashlib, json, re, sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))
from importer.parser import ImportFailure, parse_pdf  # noqa: E402

GRADES = {"5", "6", "7", "8", "9"}

def folder_grade(name: str) -> int:
    m = re.fullmatch(r"\s*([5-9])(?:\s*(?:класс|class|klass))?\s*", name, re.I)
    if not m: raise ImportFailure(f"Класс не определён по папке: {name}")
    return int(m.group(1))

def grade_from(path: Path, root: Path) -> int:
    parts = path.relative_to(root).parts
    if not parts: raise ImportFailure(f"Путь вне каталога источника: {path}")
    return folder_grade(parts[0])

def slug(value: str) -> str:
    value = value.lower().replace("ё", "е")
    value = re.sub(r"[^a-zа-я0-9]+", "-", value, flags=re.I).strip("-")
    return value or "book"

def capitalise(value: str) -> str:
    value = value.strip()
    for i, c in enumerate(value):
        if c.isalpha(): return value[:i] + c.upper() + value[i + 1:]
    return value

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""): h.update(chunk)
    return h.hexdigest()

def subject(path: Path) -> tuple[str, str]:
    n = path.name.lower()
    if re.search(r"всеобщ|vseob", n): return "world_history", "Всеобщая история"
    return "russian_history", "История России"

def build_book(path: Path, source_root: Path) -> dict:
    grade = grade_from(path, source_root)
    digest = sha256(path)
    sid, stitle = subject(path)
    parsed = parse_pdf(path)
    book_slug = slug(path.stem)
    sections = []
    for i, s in enumerate(parsed.sections, 1):
        sections.append({"number": s.get("number", i), "title": capitalise(s.get("title", "")), "paragraphs": []})
    used_ids: set[str] = set()
    review = 0
    for i, p in enumerate(parsed.paragraphs, 1):
        number = p.number
        key = str(number).replace("–", "-")
        pid = f"{grade}-{book_slug}-p{key}"
        if pid in used_ids: pid = f"{pid}-{i}"
        used_ids.add(pid)
        text = p.content.strip()
        pages = sorted(set(p.pages))
        item = {"id": pid, "number": number, "title": capitalise(p.title), "pages": pages, "text": text,
                "requiring_review": bool(len(text) < 100 or not pages)}
        if item["requiring_review"]: review += 1
        index = p.section if isinstance(p.section, int) else -1
        if 0 <= index < len(sections): sections[index]["paragraphs"].append(item)
        elif sections: sections[-1]["paragraphs"].append(item)
        else: sections.append({"number": 1, "title": "", "paragraphs": [item]})
    issues = list(parsed.issues)
    if not sections: issues.append("Разделы не распознаны")
    if not parsed.paragraphs: issues.append("Параграфы не распознаны")
    return {"schema_version": "historycore.textbook.v2", "grade": grade,
            "textbook": {"title": path.stem.replace("_", " ").replace("-", " "), "year": None, "authors": [], "publisher": None,
                         "subject": {"id": sid, "title": stitle}, "source_file": path.name,
                         "source": {"filename": path.name, "sha256": digest}, "legal_source": None},
            "sections": sections, "pages": [{"number": x.number, "used_ocr": x.used_ocr, "issues": x.issues} for x in parsed.pages],
            "issues": issues, "stats": {"pages": len(parsed.pages), "sections": len(sections), "paragraphs": len(parsed.paragraphs), "review": review},
            "status": "NEEDS_REVIEW" if issues or review else "OK"}

def validate(data: dict) -> list[str]:
    errors, ids = [], set()
    for s in data.get("sections", []):
        for p in s.get("paragraphs", []):
            for field in ("id", "number", "title", "pages", "text"):
                if field not in p or p[field] in (None, "", []): errors.append(f"{p.get('id','<без id>')}: пустое поле {field}")
            if p.get("id") in ids: errors.append(f"дубликат id: {p['id']}")
            ids.add(p.get("id"))
    try: json.dumps(data, ensure_ascii=False)
    except (TypeError, ValueError) as e: errors.append(f"JSON: {e}")
    return errors

def discover(root: Path) -> list[Path]:
    result = []
    for p in root.rglob("*.pdf"):
        if p.is_file():
            try: folder_grade(p.relative_to(root).parts[0]); result.append(p)
            except ImportFailure: pass
    return sorted(result)

def write_json(data: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)

def main() -> int:
    ap = argparse.ArgumentParser(description="PDF учебников 5–9 классов → JSON")
    ap.add_argument("source", nargs="?", type=Path, default=ROOT / "pdf")
    ap.add_argument("--output", type=Path, default=ROOT / "data")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args(); files = discover(args.source)
    if not files: print("ERROR: PDF-файлы 5–9 классов не найдены", file=sys.stderr); return 2
    books, errors = [], []
    for path in files:
        try:
            grade = grade_from(path, args.source); out = args.output / str(grade) / (slug(path.stem) + ".json"); digest = sha256(path)
            if out.exists() and not args.force:
                old = json.loads(out.read_text(encoding="utf-8"))
                if old.get("textbook", {}).get("source", {}).get("sha256") == digest:
                    stats = old.get("stats", {}); books.append({"file": path.name, "grade": grade, "status": old.get("status", "SKIPPED"), "skipped": True, **stats, "json": str(out)}); print(f"SKIPPED {path.name}"); continue
            data = build_book(path, args.source); problems = validate(data)
            if problems: errors.extend([f"{path.name}: {x}" for x in problems]); data["status"] = "ERROR"
            if not args.dry_run: write_json(data, out)
            item = {"file": path.name, "grade": grade, "status": data["status"], **data["stats"], "json": str(out)}; books.append(item)
            print(f"{data['status']}: {path.name} — {data['stats']['paragraphs']} параграфов")
        except (ImportFailure, OSError, ValueError, KeyError) as e: errors.append(f"{path.name}: {e}"); print(f"ERROR: {path.name}: {e}")
    report = {"schema_version": "historycore.import-report.v2", "generated_at": datetime.now(timezone.utc).isoformat(), "source": str(args.source), "dry_run": args.dry_run, "books": books, "errors": errors,
              "summary": {"grades": "5–9", "pdf_found": len(files), "pdf_success": sum(x["status"] in ("OK", "NEEDS_REVIEW", "SKIPPED") for x in books), "pdf_needs_review": sum(x["status"] == "NEEDS_REVIEW" for x in books), "pdf_errors": len(errors), "sections": sum(x.get("sections", 0) for x in books), "paragraphs": sum(x.get("paragraphs", 0) for x in books)}}
    if not args.dry_run: write_json(report, args.output / "import-report.json")
    print("ОБРАБОТКА ЗАВЕРШЕНА"); print(json.dumps(report["summary"], ensure_ascii=False, indent=2))
    return 1 if errors else 0

if __name__ == "__main__": raise SystemExit(main())
