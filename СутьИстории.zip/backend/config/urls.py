from django.contrib import admin
from django.urls import path
from api import views as v
urlpatterns = [
    path('', v.home),
    path('admin/private-image/<int:pk>/', v.private_image),
    path('admin/', admin.site.urls),
    path('api/grades/', v.Grades.as_view()),
    path('api/subjects/', v.Subjects.as_view()),
    path('api/textbooks/', v.Textbooks.as_view()),
    path('api/sections/', v.Sections.as_view()),
    path('api/paragraphs/', v.Paragraphs.as_view()),
    path('api/summaries/generate/', v.GenerateSummary.as_view()),
    path('api/summaries/regenerate/', v.RegenerateSummary.as_view()),
    path('api/summaries/<int:pk>/', v.ReadSummary.as_view()),
    path('api/tests/generate/', v.GenerateTest.as_view()),
    path('api/attempts/<uuid:pk>/', v.AttemptDetail.as_view()),
    path('api/attempts/<uuid:pk>/answers/', v.SaveAnswer.as_view()),
    path('api/attempts/<uuid:pk>/complete/', v.CompleteAttempt.as_view()),
    path('api/attempts/<uuid:pk>/result/', v.Result.as_view()),
    path('api/attempts/<uuid:pk>/retry/', v.RetryAttempt.as_view()),
]
