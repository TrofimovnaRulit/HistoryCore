import hashlib
import json
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class Subject(models.Model):
    slug = models.SlugField(unique=True)
    title = models.CharField(max_length=150)
    class Meta:
        verbose_name = 'Предмет'
        verbose_name_plural = 'Предметы'
    def __str__(self): return self.title

class Textbook(models.Model):
    title = models.CharField('Название', max_length=300)
    subject = models.ForeignKey(Subject, on_delete=models.PROTECT)
    grade = models.PositiveSmallIntegerField('Класс', validators=[MinValueValidator(5), MaxValueValidator(11)])
    year = models.PositiveSmallIntegerField('Год', null=True, blank=True)
    publisher = models.CharField('Издательство', max_length=200, blank=True)
    isbn = models.CharField('ISBN', max_length=32, blank=True, db_index=True)
    source_filename = models.CharField(max_length=255, blank=True, db_index=True)
    source_hash = models.CharField(max_length=64, blank=True, db_index=True)
    legal_source = models.TextField('Основание использования', blank=True)
    is_published = models.BooleanField('Доступен школьникам', default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        verbose_name = 'Учебник'
        verbose_name_plural = 'Учебники'
        ordering = ['grade', 'title']
    def __str__(self): return f'{self.title}, {self.grade} класс'

class Section(models.Model):
    textbook = models.ForeignKey(Textbook, on_delete=models.CASCADE, related_name='sections')
    number = models.CharField('Номер', max_length=30)
    title = models.CharField('Название', max_length=400)
    order = models.PositiveIntegerField(default=0)
    class Meta:
        ordering = ['order', 'id']
        verbose_name = 'Раздел'
        verbose_name_plural = 'Разделы'
    def __str__(self): return self.title

class Paragraph(models.Model):
    section = models.ForeignKey(Section, on_delete=models.CASCADE, related_name='paragraphs')
    source_id = models.CharField('ID в JSON-каталоге', max_length=180, blank=True, db_index=True)
    number = models.CharField('Номер', max_length=30)
    title = models.CharField('Название', max_length=500)
    content = models.TextField('Исходный текст (закрытый)')
    source_pages = models.JSONField(default=list)
    requiring_review = models.BooleanField('Нужна проверка', default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        ordering = ['id']
        verbose_name = 'Параграф'
        verbose_name_plural = 'Параграфы'
    @property
    def source_version(self):
        book = self.section.textbook
        value = [self.content, self.title, self.number, book.grade, book.subject_id]
        return hashlib.sha256(json.dumps(value, ensure_ascii=False).encode()).hexdigest()
    def __str__(self): return f'§ {self.number}. {self.title}'

class SourcePage(models.Model):
    textbook = models.ForeignKey(Textbook, on_delete=models.CASCADE, related_name='source_pages')
    number = models.PositiveIntegerField()
    raw_text = models.TextField()
    used_ocr = models.BooleanField(default=False)
    issues = models.JSONField(default=list)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['textbook', 'number'], name='unique_source_page')]

class ParagraphImage(models.Model):
    textbook = models.ForeignKey(Textbook, on_delete=models.CASCADE, related_name='images')
    paragraph = models.ForeignKey(Paragraph, null=True, blank=True, on_delete=models.SET_NULL, related_name='images')
    file = models.FileField(upload_to='images/%Y/%m/')
    page_number = models.PositiveIntegerField()
    caption = models.TextField(blank=True)
    order = models.PositiveIntegerField(default=0)
    requiring_review = models.BooleanField(default=True)
    class Meta:
        ordering = ['page_number', 'order']
        verbose_name = 'Изображение'
        verbose_name_plural = 'Изображения'
