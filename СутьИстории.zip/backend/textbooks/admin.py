from django.contrib import admin
from .models import Subject, Textbook, Section, Paragraph, ParagraphImage
class SectionInline(admin.TabularInline):
    model = Section
    extra = 0
    show_change_link = True
class ParagraphInline(admin.TabularInline):
    model = Paragraph
    fields = ['number', 'title', 'requiring_review']
    extra = 0
    show_change_link = True
@admin.register(Textbook)
class TextbookAdmin(admin.ModelAdmin):
    list_display = ['title', 'grade', 'subject', 'is_published', 'legal_source']
    list_filter = ['grade', 'subject', 'is_published']
    search_fields = ['title', 'isbn']
    inlines = [SectionInline]
@admin.register(Section)
class SectionAdmin(admin.ModelAdmin):
    list_display = ['title', 'textbook', 'order']
    list_filter = ['textbook']
    inlines = [ParagraphInline]
@admin.action(description='Отметить выбранные параграфы проверенными')
def mark_reviewed(modeladmin, request, queryset): queryset.update(requiring_review=False)
@admin.register(Paragraph)
class ParagraphAdmin(admin.ModelAdmin):
    list_display = ['number', 'title', 'section', 'requiring_review']
    list_filter = ['requiring_review', 'section__textbook']
    search_fields = ['title', 'number']
    actions = [mark_reviewed]
@admin.register(ParagraphImage)
class ImageAdmin(admin.ModelAdmin):
    list_display = ['id', 'textbook', 'paragraph', 'page_number', 'requiring_review']
    list_filter = ['requiring_review', 'textbook']
    readonly_fields = ['private_preview']
    exclude = ['file']
    def private_preview(self, obj):
        from django.utils.html import format_html
        return format_html('<a href="/admin/private-image/{}/">Просмотреть изображение</a>', obj.pk)
admin.site.register(Subject)
admin.site.site_header = 'Суть истории · Редакция'
admin.site.site_title = 'Суть истории'
