from pathlib import Path
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
class Command(BaseCommand):
    help = 'Рекурсивный импорт PDF; ошибка одного файла не прерывает остальные.'
    def add_arguments(self, parser):
        parser.add_argument('directory')
        parser.add_argument('--dry-run', action='store_true')
        parser.add_argument('--force', action='store_true')
        parser.add_argument('--legal-source', default='')
        parser.add_argument('--extract-images', action='store_true')
    def handle(self, *args, **options):
        root = Path(options['directory'])
        if not root.is_dir(): raise CommandError('Папка не найдена.')
        files = sorted(p for p in root.rglob('*') if p.suffix.lower() == '.pdf')
        failed = 0
        for path in files:
            try:
                call_command('import_textbook', str(path), dry_run=options['dry_run'], force=options['force'], legal_source=options['legal_source'], extract_images=options['extract_images'], stdout=self.stdout)
            except Exception as exc:
                failed += 1
                # Avoid dumping extracted content or unexpected exception payloads.
                message = str(exc) if isinstance(exc, CommandError) else 'Не удалось обработать файл; проверьте PDF и настройки.'
                self.stderr.write(f'{path.name}: {message}')
        self.stdout.write(f'Файлов: {len(files)}. Успешно: {len(files)-failed}. Ошибок: {failed}.')
        if failed: raise CommandError('Часть файлов не импортирована. Остальные файлы обработаны.')
