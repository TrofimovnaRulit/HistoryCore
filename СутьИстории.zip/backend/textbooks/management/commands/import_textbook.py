from django.core.management.base import BaseCommand, CommandError
from importer.service import import_book
from importer.parser import ImportFailure

class Command(BaseCommand):
    help = 'Импорт PDF в закрытую базу с обязательной редакторской проверкой.'
    def add_arguments(self, parser):
        parser.add_argument('path')
        parser.add_argument('--grade', type=int)
        parser.add_argument('--subject')
        parser.add_argument('--title')
        parser.add_argument('--publisher')
        parser.add_argument('--isbn')
        parser.add_argument('--year', type=int)
        parser.add_argument('--legal-source')
        parser.add_argument('--dry-run', action='store_true')
        parser.add_argument('--force', action='store_true')
        parser.add_argument('--extract-images', action='store_true')
    def handle(self, *args, **options):
        try: meta, parsed, images, book = import_book(options['path'], options)
        except ImportFailure as exc: raise CommandError(str(exc)) from None
        self.stdout.write('DRY RUN' if options['dry_run'] else 'IMPORT COMPLETE')
        self.stdout.write(f'Book: {meta["title"]}\nPages: {len(parsed.pages)}\nSections: {len(parsed.sections)}\nParagraphs: {len(parsed.paragraphs)}\nImages: {images}\nNeeds review: {len(parsed.paragraphs)}')
        for i, section in enumerate(parsed.sections):
            self.stdout.write(f'  Раздел {section["number"]}: {section["title"]}')
            for p in parsed.paragraphs:
                if p.section == i: self.stdout.write(f'    § {p.number}. {p.title} | PDF-страницы: {p.pages}')
        for issue in parsed.issues: self.stdout.write(f'Проблема на странице {issue["page"]}: {"; ".join(issue["issues"])}')
        if not options['dry_run']: self.stdout.write('Проверьте параграфы в /admin/, укажите основание использования и включите публикацию учебника.')
