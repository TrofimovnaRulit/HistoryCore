"""Load the reviewed JSON catalog into the runtime index used by the site.

JSON remains the source of truth. The Django tables are only a runtime lookup
index for the current MVP and can be rebuilt at any time from data/5…9.
"""
import json
from pathlib import Path
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from textbooks.models import Subject, Textbook, Section, Paragraph


class Command(BaseCommand):
    help = 'Синхронизировать data/5…9 с каталогом HistoryCore.'

    def add_arguments(self, parser):
        parser.add_argument('--source', default='data')
        parser.add_argument('--publish', action='store_true', help='Сделать материалы доступными в школьном интерфейсе.')

    @transaction.atomic
    def handle(self, *args, **options):
        root = Path(options['source'])
        files = sorted(p for p in root.glob('[5-9]/*.json') if p.name != 'import-report.json')
        if not files:
            raise CommandError(f'В {root} нет JSON-каталога.')
        total = 0
        for path in files:
            data = json.loads(path.read_text(encoding='utf-8'))
            textbook = data['textbook']
            subject_data = textbook.get('subject') or {'id': 'history', 'title': 'История'}
            subject, _ = Subject.objects.update_or_create(
                slug=subject_data['id'], defaults={'title': subject_data['title']}
            )
            book, _ = Textbook.objects.update_or_create(
                source_filename=textbook['source_file'],
                defaults={
                    'title': textbook.get('title') or textbook['source_file'], 'subject': subject,
                    'grade': data['grade'], 'source_hash': textbook.get('source', {}).get('sha256', ''),
                    'legal_source': textbook.get('legal_source') or 'Локальный JSON-каталог, ожидает юридической проверки.',
                    'is_published': bool(options['publish']),
                },
            )
            book.sections.all().delete()
            sections = {}
            for order, item in enumerate(data['sections'], 1):
                section = Section.objects.create(
                    textbook=book, number=item['number'], title=item['title'], order=order
                )
                for item in item.get('paragraphs', []):
                    Paragraph.objects.create(section=section, source_id=item['id'], number=item['number'], title=item['title'],
                                             content=item['text'], source_pages=item['pages'], requiring_review=item.get('requiring_review', False))
                    total += 1
        self.stdout.write(self.style.SUCCESS(
            f'JSON catalog synced: {len(files)} books, {total} paragraphs. Published: {options["publish"]}.'
        ))
