import uuid
from django.db import models
class Test(models.Model):
    summary = models.ForeignKey('summaries.Summary', on_delete=models.CASCADE, related_name='tests')
    created_at = models.DateTimeField(auto_now_add=True)
    question_count = models.PositiveSmallIntegerField()

class TestQuestion(models.Model):
    test = models.ForeignKey(Test, on_delete=models.CASCADE, related_name='questions')
    question_text = models.TextField()
    order = models.PositiveSmallIntegerField()
    correct_option = models.PositiveSmallIntegerField()
    class Meta:
        ordering = ['order']
        constraints = [models.UniqueConstraint(fields=['test', 'order'], name='unique_question_order')]

class TestOption(models.Model):
    question = models.ForeignKey(TestQuestion, on_delete=models.CASCADE, related_name='options')
    option_text = models.CharField(max_length=1000)
    order = models.PositiveSmallIntegerField()
    class Meta:
        ordering = ['order']
        constraints = [models.UniqueConstraint(fields=['question', 'order'], name='unique_option_order')]

class TestAttempt(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    test = models.ForeignKey(Test, on_delete=models.CASCADE, related_name='attempts')
    session_key = models.CharField(max_length=40, db_index=True)
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    score = models.PositiveSmallIntegerField(default=0)
    total_questions = models.PositiveSmallIntegerField(default=0)
    percentage = models.PositiveSmallIntegerField(default=0)

class TestAnswer(models.Model):
    attempt = models.ForeignKey(TestAttempt, on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(TestQuestion, on_delete=models.CASCADE)
    selected_option = models.ForeignKey(TestOption, on_delete=models.CASCADE)
    is_correct = models.BooleanField(null=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['attempt', 'question'], name='one_answer_per_question')]
