from django.conf import settings
from django.db import transaction
from ai.providers import get_provider, ProviderError
from .models import Test, TestQuestion, TestOption

def validate_questions(data, limit):
    if not isinstance(data, dict) or set(data) != {'questions'}:
        raise ProviderError('Не удалось составить тест. Попробуйте ещё раз.')
    questions = data['questions']
    if not isinstance(questions, list) or not 1 <= len(questions) <= limit:
        raise ProviderError('Получено неверное количество вопросов.')
    seen = set()
    for item in questions:
        if not isinstance(item, dict) or set(item) != {'question', 'options', 'correct_option'}:
            raise ProviderError('Получен некорректный вопрос.')
        text, options, correct = item['question'], item['options'], item['correct_option']
        if not isinstance(text, str) or not text.strip() or len(text) > 2000 or text.strip().casefold() in seen:
            raise ProviderError('Получены некорректные или повторяющиеся вопросы.')
        seen.add(text.strip().casefold())
        if not isinstance(options, list) or len(options) != 4 or any(not isinstance(x, str) or not x.strip() or len(x) > 1000 for x in options):
            raise ProviderError('Получены некорректные варианты ответов.')
        if len({x.strip().casefold() for x in options}) != 4 or type(correct) is not int or not 0 <= correct < 4:
            raise ProviderError('Не удалось однозначно определить правильный ответ.')
    return questions

def generate_test(summary):
    book = summary.paragraph.section.textbook
    provider = get_provider()
    data = provider.generate_test(summary.content, book.grade, book.subject.title, book.title,
                                  summary.paragraph.number, settings.TEST_QUESTION_COUNT)
    questions = validate_questions(data, settings.TEST_QUESTION_COUNT)
    with transaction.atomic():
        test = Test.objects.create(summary=summary, question_count=len(questions))
        for i, item in enumerate(questions):
            question = TestQuestion.objects.create(test=test, question_text=item['question'].strip(), order=i, correct_option=item['correct_option'])
            TestOption.objects.bulk_create([TestOption(question=question, option_text=text.strip(), order=j) for j, text in enumerate(item['options'])])
    return test
