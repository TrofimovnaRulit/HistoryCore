from django.contrib import admin
from .models import Test, TestQuestion, TestOption, TestAttempt, TestAnswer
for model in [Test, TestQuestion, TestOption, TestAttempt, TestAnswer]:
    admin.site.register(model)
