import json
import re
import time
from abc import ABC, abstractmethod
import httpx
from django.conf import settings
from .prompts import summary_prompt, quiz_prompt

class ProviderError(Exception):
    pass

class AIProvider(ABC):
    @property
    @abstractmethod
    def model(self): ...
    @abstractmethod
    def generate_summary(self, text, mode, grade, subject): ...
    @abstractmethod
    def generate_test(self, summary, grade, subject, title, number, count): ...

class GeminiProvider(AIProvider):
    @property
    def model(self): return 'gemini:' + settings.AI_MODEL
    def _generate(self, instruction, text, structured=False):
        if not settings.AI_API_KEY:
            raise ProviderError('Сервис пересказов ещё не подключён. Обратитесь к администратору.')
        if not re.fullmatch(r'[a-zA-Z0-9._-]+', settings.AI_MODEL):
            raise ProviderError('Неверная настройка модели.')
        payload = {
            'systemInstruction': {'parts': [{'text': instruction}]},
            'contents': [{'role': 'user', 'parts': [{'text': text}]}],
            'generationConfig': {'temperature': 0.6, 'maxOutputTokens': 8192}
        }
        if structured: payload['generationConfig']['responseMimeType'] = 'application/json'
        try:
            response = None
            for attempt in range(3):
                response = httpx.post(
                    f'https://generativelanguage.googleapis.com/v1beta/models/{settings.AI_MODEL}:generateContent',
                    headers={'x-goog-api-key': settings.AI_API_KEY}, json=payload, timeout=settings.AI_TIMEOUT)
                if response.status_code not in (429, 500, 502, 503, 504):
                    break
                if attempt < 2:
                    time.sleep(1.5 * (attempt + 1))
            response.raise_for_status()
            candidate = response.json()['candidates'][0]
            if candidate.get('finishReason') != 'STOP': raise ValueError('Incomplete response')
            result = '\n'.join(p.get('text', '') for p in candidate['content']['parts'] if not p.get('thought')).strip()
            if not result or len(result) > 60000: raise ValueError('Invalid response')
            return json.loads(result) if structured else result
        except (httpx.HTTPError, KeyError, IndexError, TypeError, ValueError):
            # Never log upstream responses: they may contain source text or credentials.
            raise ProviderError('Не удалось подготовить материал. Попробуйте ещё раз немного позже.') from None
    def generate_summary(self, text, mode, grade, subject):
        return self._generate(summary_prompt(mode, grade, subject), text)
    def generate_test(self, summary, grade, subject, title, number, count):
        return self._generate(quiz_prompt(grade, subject, title, number, count), summary, True)

def get_provider():
    if settings.AI_PROVIDER != 'gemini':
        raise ProviderError('Доступен только Gemini API. Укажите AI_PROVIDER=gemini в файле .env.')
    return GeminiProvider()
