"""Conservative PDF extraction. Original page text is preserved for editorial review."""
import re
import shutil
import subprocess
import tempfile
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path
import pymupdf

class ImportFailure(Exception): pass

@dataclass
class Page:
    number: int
    raw_text: str
    used_ocr: bool = False
    issues: list = field(default_factory=list)

@dataclass
class ParsedParagraph:
    number: str
    title: str
    section: int
    lines: list = field(default_factory=list)
    pages: list = field(default_factory=list)
    requiring_review: bool = True
    @property
    def content(self):
        text = '\n'.join(self.lines)
        return re.sub(r'([а-яё])[-¬]\n([а-яё])', r'\1\2', text, flags=re.I).strip()

@dataclass
class ParsedBook:
    pages: list
    sections: list
    paragraphs: list
    issues: list

PARAGRAPH = re.compile(r'^\s*(?:§\s*|Параграф\s+)(\d{1,3}(?:\s*[–—-]\s*\d{1,3})?)\s*[.)]?\s*(.*)$', re.I)
SECTION = re.compile(r'^(?:ГЛАВА|РАЗДЕЛ|ЧАСТЬ)(?:\s+([IVXLCDM]+|\d+)(?=\s|[.:]|$)\s*[.:]?\s*(.*))?$', re.I)

def usable(text):
    chars = [c for c in text if not c.isspace()]
    if len(chars) < 60: return False
    return sum(c.isalpha() for c in chars) / len(chars) > .45 and text.count('\ufffd') / len(chars) < .03

def ocr_page(page):
    executable = shutil.which('tesseract')
    if not executable: raise ImportFailure('Для OCR установите Tesseract и языковой пакет rus.')
    with tempfile.TemporaryDirectory(prefix='history-ocr-') as temp:
        image = Path(temp) / 'page.png'
        page.get_pixmap(dpi=200).save(image)
        try:
            result = subprocess.run([executable, str(image), 'stdout', '-l', 'rus+eng'], capture_output=True, text=True, timeout=120)
        except subprocess.TimeoutExpired:
            raise ImportFailure('OCR не завершился за 120 секунд.') from None
        if result.returncode: raise ImportFailure('OCR недоступен. Проверьте установку языков rus и eng (tesseract --list-langs).')
        return result.stdout

def extract_pages(path):
    try:
        doc = pymupdf.open(path)
    except Exception:
        raise ImportFailure('Не удалось открыть PDF. Проверьте файл.') from None
    pages = []
    with doc:
        if doc.needs_pass: raise ImportFailure('PDF защищён паролем.')
        for i, page in enumerate(doc):
            text, used_ocr, issues = page.get_text(sort=False), False, []
            if not usable(text):
                try:
                    text = ocr_page(page)
                    used_ocr = True
                    if not usable(text): issues.append('Низкое качество OCR')
                except ImportFailure as exc:
                    issues.append(str(exc))
            pages.append(Page(i + 1, text, used_ocr, issues))
    return pages

def clean_line(line):
    line = line.replace('\xa0', ' ').replace('\x00', '').replace('\u00ad', '')
    return re.sub(r'[ \t]+', ' ', line).strip()

def repeated_margins(pages):
    counts = Counter()
    for page in pages:
        lines = [clean_line(x) for x in page.raw_text.splitlines() if x.strip()]
        counts.update(set(lines[:3] + lines[-2:]))
    return {line for line, count in counts.items() if count >= max(3, len(pages) * .035) and len(line) < 180}

def parse_pages(pages):
    repeated = repeated_margins(pages)
    sections, paragraphs, issues = [], [], []
    current = None
    section_index = -1
    seen_sections, seen_paragraphs = set(), set()
    for page in pages:
        lines = [clean_line(x) for x in page.raw_text.splitlines()]
        if page.issues: issues.append({'page': page.number, 'issues': page.issues})
        # TOC is metadata, not paragraph text. Preserve it in SourcePage.
        leaders = sum(bool(re.search(r'\.{3,}\s*\d+\s*$', line)) for line in lines)
        if leaders >= 3 or any(re.fullmatch(r'содержание|оглавление', line, re.I) for line in lines):
            current = None
            continue
        i = 0
        while i < len(lines):
            line = lines[i]
            i += 1
            if not line or re.fullmatch(r'\d{1,4}', line): continue
            # Running headers are only removed at page margins.
            if line in repeated and (i <= 4 or i >= len(lines)-2): continue
            normalized = re.sub(r'(?i)г\s+л\s+а\s+в\s+а', 'ГЛАВА', line)
            normalized = re.sub(r'(?i)р\s+а\s+з\s+д\s+е\s+л', 'РАЗДЕЛ', normalized)
            section = SECTION.match(normalized)
            if section:
                number, title = section.groups()
                title = title or ''
                # Ignore short running chapter labels; chapter openers carry a title.
                if not title and number and i < 5: continue
                if not title:
                    chunks = []
                    for nxt in lines[i:i+6]:
                        if not nxt: continue
                        if re.fullmatch(r'[IVXLCDM]+|\d+', nxt):
                            number = number or nxt
                            break
                        if PARAGRAPH.match(nxt) or '?' in nxt: break
                        chunks.append(nxt)
                        if len(' '.join(chunks)) > 150: break
                    title = ' '.join(chunks)
                key = (number or '', title.casefold())
                if title and key not in seen_sections:
                    seen_sections.add(key)
                    section_index = len(sections)
                    sections.append({'number': number or str(section_index+1), 'title': title[:400]})
                    current = None
                continue
            match = PARAGRAPH.match(line)
            if match:
                number, title = match.groups()
                number = re.sub(r'\s+', '', number)
                # Identical paragraph numbers on later pages are running headers.
                if number in seen_paragraphs: continue
                seen_paragraphs.add(number)
                if not title:
                    while i < len(lines) and not lines[i]: i += 1
                    if i < len(lines):
                        title = lines[i]
                        i += 1
                        # Wrap continuation: title fragments commonly begin lowercase.
                        if i < len(lines) and re.match(r'^[а-яё]', lines[i]) and len(title) < 120:
                            title += ' ' + lines[i]
                            i += 1
                if section_index < 0:
                    sections.append({'number': '1', 'title': 'Основной материал'})
                    section_index = 0
                current = ParsedParagraph(number, (title or f'Параграф {number}')[:500], section_index)
                paragraphs.append(current)
            elif current:
                current.lines.append(line)
            if current and page.number not in current.pages:
                current.pages.append(page.number)
    for p in paragraphs:
        if len(p.content) < 100: issues.append({'page': p.pages[0], 'issues': [f'§ {p.number}: слишком мало текста']})
    if not paragraphs: issues.append({'page': None, 'issues': ['Параграфы не найдены. Требуется ручная разметка.']})
    return ParsedBook(pages, sections, paragraphs, issues)

def parse_pdf(path): return parse_pages(extract_pages(path))
