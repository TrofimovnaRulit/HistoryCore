import hashlib
import re
from pathlib import Path
import pymupdf
from django.core.files.base import ContentFile
from django.db import transaction
from django.db.models import Q
from textbooks.models import Subject, Textbook, Section, Paragraph, SourcePage, ParagraphImage
from .parser import parse_pdf, ImportFailure

def infer_metadata(path, options):
    path = Path(path)
    match = re.search(r'(5|6|7|8|9|10|11)[ _-]*(?:класс|class|klass)', str(path), re.I)
    grade = options.get('grade') or (int(match[1]) if match else None)
    if grade not in range(5, 10): raise ImportFailure('Сейчас доступны 5–9 классы. Укажите --grade от 5 до 9 или папку 6_class / 6 класс.')
    subject = options.get('subject') or ('world_history' if re.search(r'vseob|всеобщ', path.name, re.I) else 'russian_history')
    subject_title = {'world_history': 'Всеобщая история', 'russian_history': 'История России'}.get(subject, subject.replace('_', ' ').capitalize())
    return {'grade': grade, 'subject_slug': subject, 'subject_title': subject_title,
            'title': options.get('title') or f'{subject_title}. {grade} класс',
            'publisher': options.get('publisher') or '', 'isbn': options.get('isbn') or '',
            'year': options.get('year'), 'legal_source': options.get('legal_source') or '', 'source_filename': path.name}

def duplicate(meta, digest):
    q = Q(source_hash=digest) | Q(source_filename=meta['source_filename'], grade=meta['grade']) | Q(title=meta['title'], grade=meta['grade'], publisher=meta['publisher'])
    if meta['isbn']: q |= Q(isbn=meta['isbn'])
    matches = list(Textbook.objects.filter(q))
    if len(matches) > 1: raise ImportFailure('Найдено несколько возможных дубликатов. Сначала устраните неоднозначность в админ-панели.')
    return matches[0] if matches else None

def import_book(path, options):
    path = Path(path)
    if not path.is_file() or path.suffix.lower() != '.pdf': raise ImportFailure('Укажите существующий PDF-файл.')
    meta = infer_metadata(path, options)
    with path.open('rb') as source:
        digest = hashlib.file_digest(source, 'sha256').hexdigest()
    existing = duplicate(meta, digest)
    if existing and not options.get('force') and not options.get('dry_run'):
        raise ImportFailure(f'Учебник уже существует (id={existing.pk}). Для повторного импорта используйте --force.')
    parsed = parse_pdf(path)
    image_count = 0
    if options.get('dry_run'):
        with pymupdf.open(path) as doc: image_count = sum(len(p.get_images(full=True)) for p in doc)
        return meta, parsed, image_count, None
    if not parsed.paragraphs: raise ImportFailure('Параграфы не найдены. База не изменена; выполните --dry-run и проверьте PDF.')
    if options.get('extract_images') and not options.get('legal_source'):
        raise ImportFailure('Для извлечения изображений укажите основание использования через --legal-source.')
    saved_files = []
    try:
        with transaction.atomic():
            subject, _ = Subject.objects.get_or_create(slug=meta.pop('subject_slug'), defaults={'title': meta.pop('subject_title')})
            if existing:
                # Preserve textbook identity; replace its derived content atomically.
                existing.sections.all().delete()
                existing.source_pages.all().delete()
                existing.images.all().delete()
                book = existing
                for key, value in meta.items(): setattr(book, key, value)
                book.subject = subject
                book.source_hash = digest
                book.is_published = False
                book.save()
            else:
                book = Textbook.objects.create(**meta, subject=subject, source_hash=digest)
            SourcePage.objects.bulk_create([SourcePage(textbook=book, number=p.number, raw_text=p.raw_text, used_ocr=p.used_ocr, issues=p.issues) for p in parsed.pages])
            sections = [Section.objects.create(textbook=book, order=i, **s) for i, s in enumerate(parsed.sections)]
            records = [Paragraph.objects.create(section=sections[p.section], number=p.number, title=p.title, content=p.content, source_pages=p.pages, requiring_review=True) for p in parsed.paragraphs]
            if options.get('extract_images'):
                with pymupdf.open(path) as doc:
                    for page_number, page in enumerate(doc, 1):
                        candidates = [p for p in records if page_number in p.source_pages]
                        for order, image in enumerate(page.get_images(full=True)):
                            try: extracted = doc.extract_image(image[0])
                            except Exception:
                                parsed.issues.append({'page': page_number, 'issues': ['Изображение не удалось извлечь']})
                                continue
                            obj = ParagraphImage(textbook=book, paragraph=candidates[0] if len(candidates)==1 else None, page_number=page_number, order=order, requiring_review=True)
                            obj.file.save(f'{digest[:12]}-{page_number}-{order}.{extracted["ext"]}', ContentFile(extracted['image']), save=False)
                            saved_files.append((obj.file.storage, obj.file.name))
                            obj.save()
                            image_count += 1
        return meta, parsed, image_count, book
    except Exception:
        for storage, name in saved_files: storage.delete(name)
        raise
