from django.db import transaction
from django.core.cache import cache
from ai.providers import get_provider, ProviderError
from ai.prompts import PROMPT_VERSION
from .models import Summary

def generate(paragraph, mode, regenerate=False):
    provider = get_provider()
    version = paragraph.source_version
    query = Summary.objects.filter(paragraph=paragraph, mode=mode, source_hash=version,
                                   model=provider.model, prompt_version=PROMPT_VERSION)
    if not regenerate:
        existing = query.order_by('-created_at').first()
        if existing: return existing, True
    lock = f'summary:{paragraph.pk}:{mode}:{version}'
    if not cache.add(lock, True, timeout=180):
        raise ProviderError('Этот пересказ уже готовится. Повторите запрос через несколько секунд.')
    try:
        if not regenerate:
            existing = query.order_by('-created_at').first()
            if existing: return existing, True
        book = paragraph.section.textbook
        content = provider.generate_summary(paragraph.content, mode, book.grade, book.subject.title)
        if not isinstance(content, str) or not content.strip() or len(content) > 60000:
            raise ProviderError('Получен неполный пересказ. Попробуйте ещё раз.')
        result = Summary.objects.create(paragraph=paragraph, mode=mode, content=content.strip(),
                    model=provider.model, source_hash=version, prompt_version=PROMPT_VERSION)
        return result, False
    finally:
        cache.delete(lock)
