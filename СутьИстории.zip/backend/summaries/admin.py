from django.contrib import admin
from .models import Summary
@admin.register(Summary)
class SummaryAdmin(admin.ModelAdmin):
    list_display = ['id', 'paragraph', 'mode', 'model', 'created_at']
    list_filter = ['mode', 'model']
    readonly_fields = ['paragraph', 'mode', 'content', 'model', 'source_hash', 'prompt_version']
    def has_add_permission(self, request): return False
