from django.db import models
class Summary(models.Model):
    MODES = [('short', 'Очень кратко'), ('normal', 'Обычный пересказ'), ('detailed', 'Подробно')]
    paragraph = models.ForeignKey('textbooks.Paragraph', on_delete=models.CASCADE, related_name='summaries')
    mode = models.CharField(max_length=12, choices=MODES)
    content = models.TextField()
    model = models.CharField(max_length=150)
    source_hash = models.CharField(max_length=64)
    prompt_version = models.CharField(max_length=20)
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        indexes = [models.Index(fields=['paragraph', 'mode', 'source_hash'])]
        verbose_name = 'Пересказ'
        verbose_name_plural = 'Пересказы'
