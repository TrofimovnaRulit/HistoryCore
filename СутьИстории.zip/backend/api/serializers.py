from rest_framework import serializers
from textbooks.models import Textbook, Section, Paragraph
from summaries.models import Summary

class StrictSerializer(serializers.Serializer):
    def to_internal_value(self, data):
        if not isinstance(data, dict): raise serializers.ValidationError({'detail': 'Ожидался JSON-объект.'})
        unknown = set(data) - set(self.fields)
        if unknown: raise serializers.ValidationError({'detail': 'Запрос содержит неподдерживаемые поля.'})
        return super().to_internal_value(data)
class GenerateInput(StrictSerializer):
    paragraph_id = serializers.IntegerField(min_value=1)
    mode = serializers.ChoiceField(choices=Summary.MODES)
class TestInput(StrictSerializer):
    summary_id = serializers.IntegerField(min_value=1)
class AnswerInput(StrictSerializer):
    question_id = serializers.IntegerField(min_value=1)
    option_id = serializers.IntegerField(min_value=1)
class CompleteInput(StrictSerializer):
    confirm_incomplete = serializers.BooleanField(default=False)
class TextbookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Textbook
        fields = ['id', 'title', 'grade', 'year', 'publisher']
class SectionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Section
        fields = ['id', 'number', 'title']
class ParagraphSerializer(serializers.ModelSerializer):
    class Meta:
        model = Paragraph
        fields = ['id', 'number', 'title']
class SummarySerializer(serializers.ModelSerializer):
    grade = serializers.IntegerField(source='paragraph.section.textbook.grade', read_only=True)
    subject = serializers.CharField(source='paragraph.section.textbook.subject.title', read_only=True)
    paragraph = ParagraphSerializer()
    class Meta:
        model = Summary
        fields = ['id', 'mode', 'content', 'paragraph', 'created_at', 'grade', 'subject']
