from rest_framework.views import exception_handler as drf_handler
from rest_framework.response import Response
from ai.providers import ProviderError

def exception_handler(exc, context):
    if isinstance(exc, ProviderError):
        return Response({'detail': str(exc)}, status=503)
    return drf_handler(exc, context)
