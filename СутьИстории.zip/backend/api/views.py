from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from django.db import transaction
from django.http import FileResponse
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect, ensure_csrf_cookie
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError
from rest_framework.throttling import AnonRateThrottle
from textbooks.models import Subject, Textbook, Section, Paragraph, ParagraphImage
from summaries.models import Summary
from summaries.services import generate
from quizzes.models import Test, TestAttempt, TestAnswer, TestOption
from quizzes.services import generate_test
from .serializers import *

@ensure_csrf_cookie
def home(request):
    return render(request, 'index.html', {'demo': False})

@staff_member_required
def private_image(request, pk):
    image = get_object_or_404(ParagraphImage, pk=pk)
    return FileResponse(image.file.open('rb'), as_attachment=False)

class GenerationThrottle(AnonRateThrottle): scope = 'generation'

@method_decorator(csrf_protect, name='dispatch')
class BaseView(APIView):
    def finalize_response(self, request, response, *args, **kwargs):
        response = super().finalize_response(request, response, *args, **kwargs)
        response['Cache-Control'] = 'no-store'
        return response

def clean_input(cls, request):
    serializer = cls(data=request.data)
    serializer.is_valid(raise_exception=True)
    return serializer.validated_data

def session_key(request):
    if not request.session.session_key: request.session.create()
    return request.session.session_key

def positive_query(request, name):
    try:
        value = int(request.query_params.get(name, ''))
        if value < 1: raise ValueError
        return value
    except ValueError: raise ValidationError({name: 'Выберите значение.'})

def public_paragraphs():
    return Paragraph.objects.filter(section__textbook__is_published=True, requiring_review=False).exclude(section__textbook__legal_source='')

class Grades(BaseView):
    def get(self, request): return Response([{'id': n, 'title': f'{n} класс'} for n in range(5, 10)])
class Subjects(BaseView):
    def get(self, request): return Response(list(Subject.objects.values('slug', 'title')))
class Textbooks(BaseView):
    def get(self, request):
        books = Textbook.objects.filter(is_published=True, grade=positive_query(request, 'grade'), subject__slug=request.query_params.get('subject', '')).exclude(legal_source='')
        return Response(TextbookSerializer(books, many=True).data)
class Sections(BaseView):
    def get(self, request):
        items = Section.objects.filter(textbook_id=positive_query(request, 'textbook'), textbook__is_published=True).exclude(textbook__legal_source='')
        return Response(SectionSerializer(items, many=True).data)
class Paragraphs(BaseView):
    def get(self, request):
        queryset = public_paragraphs()
        if request.query_params.get('section'):
            queryset = queryset.filter(section_id=positive_query(request, 'section'))
        else:
            grade = positive_query(request, 'grade')
            subject = request.query_params.get('subject', '').strip()
            if grade > 9 or not subject:
                raise ValidationError({'detail': 'Выберите класс и предмет.'})
            queryset = queryset.filter(section__textbook__grade=grade, section__textbook__subject__slug=subject)
        return Response(ParagraphSerializer(queryset.distinct(), many=True).data)
class GenerateSummary(BaseView):
    throttle_classes = [GenerationThrottle]
    regenerate = False
    def post(self, request):
        data = clean_input(GenerateInput, request)
        paragraph = get_object_or_404(public_paragraphs().select_related('section__textbook__subject'), pk=data['paragraph_id'])
        result, cached = generate(paragraph, data['mode'], self.regenerate)
        ids = request.session.get('summary_ids', [])
        request.session['summary_ids'] = list(dict.fromkeys(ids + [result.pk]))[-100:]
        return Response({**SummarySerializer(result).data, 'cached': cached})
class RegenerateSummary(GenerateSummary): regenerate = True
class ReadSummary(BaseView):
    def get(self, request, pk):
        item = get_object_or_404(Summary, pk=pk, pk__in=request.session.get('summary_ids', []))
        return Response(SummarySerializer(item).data)
class GenerateTest(BaseView):
    throttle_classes = [GenerationThrottle]
    def post(self, request):
        data = clean_input(TestInput, request)
        summary = get_object_or_404(Summary.objects.select_related('paragraph__section__textbook__subject'), pk=data['summary_id'], pk__in=request.session.get('summary_ids', []))
        test = generate_test(summary)
        attempt = TestAttempt.objects.create(test=test, session_key=session_key(request), total_questions=test.question_count)
        return Response({'attempt_id': str(attempt.pk)}, status=201)

def get_attempt(request, pk, locked=False):
    query = TestAttempt.objects.select_related('test__summary__paragraph')
    if locked: query = query.select_for_update()
    return get_object_or_404(query, pk=pk, session_key=session_key(request))

def attempt_data(attempt):
    selected = {a.question_id: a.selected_option_id for a in attempt.answers.all()}
    return {'id': str(attempt.pk), 'summary_id': attempt.test.summary_id,
            'title': str(attempt.test.summary.paragraph), 'completed': bool(attempt.completed_at),
            'questions': [{'id': q.pk, 'question': q.question_text,
                          'options': [{'id': o.pk, 'text': o.option_text} for o in q.options.all()],
                          'selected_option': selected.get(q.pk)} for q in attempt.test.questions.prefetch_related('options')]}
class AttemptDetail(BaseView):
    def get(self, request, pk): return Response(attempt_data(get_attempt(request, pk)))
class SaveAnswer(BaseView):
    @transaction.atomic
    def post(self, request, pk):
        data = clean_input(AnswerInput, request)
        attempt = get_attempt(request, pk, locked=True)
        if attempt.completed_at: return Response({'detail': 'Тест завершён. Ответы больше нельзя изменить.'}, status=409)
        option = get_object_or_404(TestOption, pk=data['option_id'], question_id=data['question_id'], question__test=attempt.test)
        TestAnswer.objects.update_or_create(attempt=attempt, question=option.question, defaults={'selected_option': option, 'is_correct': None})
        return Response({'saved': True})
class CompleteAttempt(BaseView):
    @transaction.atomic
    def post(self, request, pk):
        data = clean_input(CompleteInput, request)
        attempt = get_attempt(request, pk, locked=True)
        if attempt.completed_at: return Response({'completed': True})
        answers = list(attempt.answers.select_related('question', 'selected_option'))
        missing = attempt.total_questions - len(answers)
        if missing and not data['confirm_incomplete']:
            return Response({'detail': 'Вы ответили не на все вопросы. Всё равно завершить тест?', 'unanswered': missing}, status=409)
        for answer in answers:
            answer.is_correct = answer.selected_option.order == answer.question.correct_option
        TestAnswer.objects.bulk_update(answers, ['is_correct'])
        attempt.score = sum(a.is_correct for a in answers)
        attempt.percentage = round(attempt.score / attempt.total_questions * 100)
        attempt.completed_at = timezone.now()
        attempt.save(update_fields=['score', 'percentage', 'completed_at'])
        return Response({'completed': True})
class Result(BaseView):
    def get(self, request, pk):
        attempt = get_attempt(request, pk)
        if not attempt.completed_at: return Response({'detail': 'Сначала завершите тест.'}, status=409)
        data = attempt_data(attempt)
        correct = {q.pk: next(o.pk for o in q.options.all() if o.order == q.correct_option) for q in attempt.test.questions.prefetch_related('options')}
        for q in data['questions']:
            q['correct_option'] = correct[q['id']]
            q['is_correct'] = q['selected_option'] == q['correct_option']
        return Response({**data, 'score': attempt.score, 'total': attempt.total_questions, 'percentage': attempt.percentage})
class RetryAttempt(BaseView):
    def post(self, request, pk):
        clean_input(StrictSerializer, request)
        previous = get_attempt(request, pk)
        if not previous.completed_at: return Response({'detail': 'Сначала завершите текущий тест.'}, status=409)
        attempt = TestAttempt.objects.create(test=previous.test, session_key=session_key(request), total_questions=previous.total_questions)
        return Response({'attempt_id': str(attempt.pk)}, status=201)
