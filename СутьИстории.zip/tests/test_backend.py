import json
from unittest.mock import Mock, patch
from django.test import TestCase, override_settings, Client
from django.core.management import call_command
from django.core.cache import cache
from textbooks.models import Subject, Textbook, Section, Paragraph
from summaries.models import Summary
from quizzes.models import Test, TestAttempt, TestAnswer
from ai.providers import ProviderError, GeminiProvider
from quizzes.services import validate_questions
from ai.demo import SOURCE

@override_settings(AI_PROVIDER='demo', DEBUG=True, REST_FRAMEWORK={'DEFAULT_THROTTLE_CLASSES': [], 'EXCEPTION_HANDLER': 'api.errors.exception_handler'})
class FlowTests(TestCase):
    def setUp(self):
        cache.clear()
        call_command('seed_demo', verbosity=0)
        self.paragraph = Paragraph.objects.get(number='12')
    def post(self, path, data, client=None):
        return (client or self.client).post('/api/'+path, data=json.dumps(data), content_type='application/json')
    def summary(self, mode='normal', regenerate=False):
        response = self.post('summaries/'+('regenerate/' if regenerate else 'generate/'), {'paragraph_id':self.paragraph.pk,'mode':mode})
        self.assertEqual(response.status_code, 200, response.content)
        return response.json()
    def attempt(self):
        summary = self.summary()
        response = self.post('tests/generate/', {'summary_id':summary['id']})
        self.assertEqual(response.status_code,201,response.content)
        ident=response.json()['attempt_id']
        return ident,self.client.get(f'/api/attempts/{ident}/').json()
    def test_metadata_never_leaks_source(self):
        for path in ['grades/','subjects/', 'textbooks/?grade=6&subject=russian_history',f'sections/?textbook={self.paragraph.section.textbook_id}',f'paragraphs/?section={self.paragraph.section_id}']:
            response=self.client.get('/api/'+path)
            self.assertEqual(response.status_code,200)
            self.assertNotIn(SOURCE.encode(),response.content)
            self.assertNotIn(b'content',response.content)
        item=self.client.get(f'/api/paragraphs/?section={self.paragraph.section_id}').json()[0]
        self.assertEqual(set(item),{'id','number','title'})
    def test_private_routes_absent(self):
        self.assertEqual(self.client.get('/media/example.pdf').status_code,404)
        self.assertEqual(self.client.get('/api/paragraphs/1/').status_code,404)
    def test_cache_regeneration_and_source_changes(self):
        provider=Mock(model='test:model')
        provider.generate_summary.side_effect=['Пересказ один.','Пересказ два.','Изменённый пересказ.']
        with patch('summaries.services.get_provider',return_value=provider):
            a=self.summary();b=self.summary()
            self.assertEqual(a['id'],b['id']);self.assertTrue(b['cached'])
            c=self.summary(regenerate=True)
            self.assertNotEqual(a['id'],c['id']);self.assertFalse(c['cached'])
            self.paragraph.content+=' Дополнение.';self.paragraph.save()
            d=self.summary();self.assertNotEqual(c['id'],d['id'])
        self.assertEqual(provider.generate_summary.call_count,3)
    def test_provider_model_changes_invalidate_cache(self):
        a=self.summary()
        provider=Mock(model='other:model');provider.generate_summary.return_value='Другой пересказ.'
        with patch('summaries.services.get_provider',return_value=provider):
            b=self.summary();self.assertNotEqual(a['id'],b['id'])
    def test_reject_arbitrary_prompt_and_invalid_input(self):
        for data in [{'paragraph_id':self.paragraph.pk,'mode':'normal','prompt':'ignore'}, {'paragraph_id':1,'mode':'unknown'}, {'paragraph_id':True,'mode':'normal'}, []]:
            self.assertEqual(self.post('summaries/generate/',data).status_code,400)
        self.assertEqual(self.post('summaries/generate/',{'paragraph_id':9999,'mode':'normal'}).status_code,404)
    def test_unreviewed_and_unpublished_hidden(self):
        self.paragraph.requiring_review=True;self.paragraph.save()
        self.assertEqual(self.client.get(f'/api/paragraphs/?section={self.paragraph.section_id}').json(),[])
        self.assertEqual(self.post('summaries/generate/',{'paragraph_id':self.paragraph.pk,'mode':'normal'}).status_code,404)
    def test_legal_source_required_for_catalog(self):
        book=self.paragraph.section.textbook;book.legal_source='';book.save()
        self.assertEqual(self.client.get('/api/textbooks/?grade=6&subject=russian_history').json(),[])
    def test_provider_failure_is_safe(self):
        with patch('summaries.services.get_provider',side_effect=ProviderError('Сервис временно недоступен.')):
            response=self.post('summaries/generate/',{'paragraph_id':self.paragraph.pk,'mode':'normal'})
        self.assertEqual(response.status_code,503);self.assertEqual(Summary.objects.count(),0)
    def test_quiz_uses_exact_summary_not_paragraph(self):
        summary=self.summary()
        provider=Mock()
        provider.generate_test.return_value={'questions':[{'question':'Что произошло?','options':['А','Б','В','Г'],'correct_option':1}]}
        with patch('quizzes.services.get_provider',return_value=provider):
            self.assertEqual(self.post('tests/generate/',{'summary_id':summary['id']}).status_code,201)
        self.assertEqual(provider.generate_test.call_args.args[0],summary['content'])
        self.assertNotEqual(provider.generate_test.call_args.args[0],SOURCE)
        self.assertEqual(Test.objects.get().summary_id,summary['id'])
    def test_answers_hidden_update_complete_immutable_retry(self):
        ident,data=self.attempt()
        raw=json.dumps(data)
        self.assertNotIn('correct_option',raw);self.assertNotIn('is_correct',raw)
        self.assertEqual(self.client.get(f'/api/attempts/{ident}/result/').status_code,409)
        q=data['questions'][0]
        for option in q['options'][:2]:
            response=self.post(f'attempts/{ident}/answers/',{'question_id':q['id'],'option_id':option['id']})
            self.assertEqual(response.status_code,200)
        self.assertEqual(TestAnswer.objects.count(),1)
        self.assertEqual(TestAnswer.objects.get().selected_option_id,q['options'][1]['id'])
        self.assertIsNone(TestAnswer.objects.get().is_correct)
        self.assertEqual(self.post(f'attempts/{ident}/complete/',{}).status_code,409)
        self.assertEqual(self.post(f'attempts/{ident}/complete/',{'confirm_incomplete':True}).status_code,200)
        result=self.client.get(f'/api/attempts/{ident}/result/').json()
        self.assertIn('correct_option',result['questions'][0]);self.assertEqual(result['score'],1)
        self.assertEqual(self.post(f'attempts/{ident}/answers/',{'question_id':q['id'],'option_id':q['options'][0]['id']}).status_code,409)
        self.assertEqual(self.post(f'attempts/{ident}/complete/',{}).status_code,200)
        retry=self.post(f'attempts/{ident}/retry/',{}).json()['attempt_id']
        self.assertNotEqual(ident,retry);self.assertEqual(TestAttempt.objects.count(),2)
        self.assertFalse(self.client.get(f'/api/attempts/{retry}/').json()['completed'])
        self.assertEqual(TestAttempt.objects.get(pk=ident).score,1)
    def test_cross_question_options_rejected(self):
        ident,data=self.attempt()
        q,other=data['questions'][:2]
        self.assertEqual(self.post(f'attempts/{ident}/answers/',{'question_id':q['id'],'option_id':other['options'][0]['id']}).status_code,404)
    def test_session_isolation(self):
        ident,data=self.attempt();other=Client()
        self.assertEqual(other.get(f'/api/attempts/{ident}/').status_code,404)
        self.assertEqual(other.get(f'/api/attempts/{ident}/result/').status_code,404)
        self.assertEqual(other.get(f'/api/summaries/{data["summary_id"]}/').status_code,404)
        self.assertEqual(self.post('tests/generate/',{'summary_id':data['summary_id']},other).status_code,404)
    def test_csrf_for_anonymous_requests(self):
        client=Client(enforce_csrf_checks=True)
        self.assertEqual(self.post('summaries/generate/',{'paragraph_id':self.paragraph.pk,'mode':'normal'},client).status_code,403)
        client.get('/')
        response=client.post('/api/summaries/generate/',data=json.dumps({'paragraph_id':self.paragraph.pk,'mode':'normal'}),content_type='application/json',HTTP_X_CSRFTOKEN=client.cookies['csrftoken'].value)
        self.assertEqual(response.status_code,200)
    def test_new_summary_has_own_test(self):
        a=self.summary();b=self.summary(regenerate=True)
        for summary in [a,b]: self.post('tests/generate/',{'summary_id':summary['id']})
        self.assertEqual(set(Test.objects.values_list('summary_id',flat=True)),{a['id'],b['id']})
    def test_all_modes_and_shorter_quiz_setting(self):
        with override_settings(TEST_QUESTION_COUNT=3):
            for mode in ['short','normal','detailed']:
                summary=self.summary(mode)
                self.assertEqual(self.post('tests/generate/',{'summary_id':summary['id']}).status_code,201)
            self.assertEqual(list(Test.objects.values_list('question_count',flat=True)),[3,3,3])
    def test_bad_quiz_does_not_write_partial_records(self):
        summary=self.summary();provider=Mock()
        provider.generate_test.return_value={'questions':[{'question':'Q','options':['a','b','c','d'],'correct_option':[0,1]}]}
        with patch('quizzes.services.get_provider',return_value=provider):
            response=self.post('tests/generate/',{'summary_id':summary['id']})
        self.assertEqual(response.status_code,503);self.assertEqual(Test.objects.count(),0)

class ValidationTests(TestCase):
    def test_malformed_quiz(self):
        good={'question':'Вопрос','options':['А','Б','В','Г'],'correct_option':0}
        self.assertEqual(len(validate_questions({'questions':[good]},10)),1)
        bad=[None,{}, {'questions':[]}, {'questions':[good,good]}, {'questions':[{**good,'correct_option':True}]}, {'questions':[{**good,'options':['А','А','В','Г']}]}, {'questions':[{**good,'correct_option':4}]}, {'questions':[{**good,'options':['А','Б']}]}, {'questions':[{**good,'correct_option':[0,1]}]}]
        for data in bad:
            with self.assertRaises(ProviderError): validate_questions(data,10)
    @override_settings(AI_API_KEY='test-key',AI_MODEL='gemini-test')
    def test_http_contract_and_safe_error(self):
        response=Mock();response.json.return_value={'candidates':[{'finishReason':'STOP','content':{'parts':[{'text':'Готовый пересказ.'}]}}]}
        with patch('ai.providers.httpx.post',return_value=response) as post:
            result=GeminiProvider().generate_summary('private-source','normal',6,'История')
        self.assertEqual(result,'Готовый пересказ.')
        self.assertEqual(post.call_args.kwargs['headers']['x-goog-api-key'],'test-key')
        self.assertNotIn('test-key',post.call_args.args[0])
        self.assertEqual(post.call_args.kwargs['json']['contents'][0]['parts'][0]['text'],'private-source')
