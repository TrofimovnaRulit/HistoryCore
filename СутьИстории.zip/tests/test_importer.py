from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import pymupdf
from django.test import TestCase, SimpleTestCase
from django.core.management import call_command
from django.core.management.base import CommandError
from importer.parser import Page, parse_pages, clean_line, usable, ImportFailure, extract_pages
from importer.service import import_book
from textbooks.models import Textbook, Paragraph, SourcePage

class ParserTests(SimpleTestCase):
    def test_paragraph_boundaries_and_sections(self):
        book=parse_pages([Page(1,'Глава I. Древний мир\n§ 1. Первая тема\n'+('Содержательный текст. '*20)+'\n§ 2. Вторая тема\n'+('Другой текст. '*20)),Page(2,'Глава II. Средневековье\n§ 3\nТретья тема\nПоследний текст.')])
        self.assertEqual(len(book.sections),2)
        self.assertEqual([p.number for p in book.paragraphs],['1','2','3'])
        self.assertEqual(book.paragraphs[2].title,'Третья тема')
        self.assertNotIn('Другой',book.paragraphs[0].content)
        self.assertEqual(book.paragraphs[2].pages,[2])
    def test_running_header_not_new_paragraph(self):
        book=parse_pages([Page(1,'§ 1. Начало\nСодержание.'),Page(2,'2\n§ 1. Начало\nПродолжение.\n§ 2. Конец\nФинал.')])
        self.assertEqual(len(book.paragraphs),2)
        self.assertIn('Продолжение',book.paragraphs[0].content)
        self.assertEqual(book.paragraphs[0].pages,[1,2])
    def test_toc_excluded(self):
        book=parse_pages([Page(1,'Содержание\n§ 1. Тема .... 3\n§ 2. Ещё .... 5'),Page(3,'§ 1. Тема\nНастоящий текст.')])
        self.assertEqual(len(book.paragraphs),1)
        self.assertEqual(book.paragraphs[0].pages,[3])
    def test_cleaning_and_raw_preserved(self):
        self.assertEqual(clean_line(' Слово\xa0  слово\x00 '),'Слово слово')
        pages=[Page(i,f'Повторяющийся заголовок\n{ i }\n'+('§ 1. Тема\n' if i==1 else '')+'полезный текст\nПодвал') for i in range(1,5)]
        book=parse_pages(pages)
        self.assertNotIn('Подвал',book.paragraphs[0].content)
        self.assertIn('Подвал',book.pages[0].raw_text)
    def test_quality(self):
        self.assertFalse(usable('�'*200));self.assertFalse(usable(' '));self.assertTrue(usable('История государства и общества. '*50))

class ImportTests(TestCase):
    def setUp(self):
        self.temp=TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.path=Path(self.temp.name)/'6_class'/'russian_history.pdf';self.path.parent.mkdir()
        with pymupdf.open() as doc:
            page=doc.new_page()
            page.insert_text((40,50),'Test PDF with sufficient original text. '*3)
            doc.save(self.path)
        self.pages=[Page(1,'Глава I. История\n§ 1. Тема\n'+('Учебный текст. '*30))]
    def run_import(self,**extra):
        with patch('importer.parser.extract_pages',return_value=self.pages):
            return import_book(self.path,{'grade':6,'legal_source':'Original test fixture',**extra})
    def test_dry_run_no_writes_and_real_import(self):
        self.run_import(dry_run=True)
        self.assertEqual(Textbook.objects.count(),0)
        self.run_import()
        self.assertEqual(Textbook.objects.count(),1);self.assertEqual(Paragraph.objects.count(),1)
        self.assertTrue(Paragraph.objects.get().requiring_review)
        self.assertFalse(Textbook.objects.get().is_published)
        self.assertEqual(SourcePage.objects.get().raw_text,self.pages[0].raw_text)
    def test_duplicate_force_keeps_identity(self):
        self.run_import();ident=Textbook.objects.get().pk
        with self.assertRaises(ImportFailure):self.run_import()
        self.run_import(force=True)
        self.assertEqual(Textbook.objects.get().pk,ident);self.assertEqual(Paragraph.objects.count(),1)
    def test_force_failure_keeps_old_book(self):
        self.run_import()
        with patch('importer.parser.extract_pages',return_value=[Page(1,'Нет разметки')]):
            with self.assertRaises(ImportFailure):import_book(self.path,{'grade':6,'force':True})
        self.assertEqual(Paragraph.objects.count(),1)
    def test_actual_pymupdf_extraction(self):
        pages=extract_pages(self.path)
        self.assertIn('Test PDF',pages[0].raw_text);self.assertFalse(pages[0].used_ocr)
    def test_ocr_fallback_and_failure(self):
        scan=Path(self.temp.name)/'scan.pdf'
        with pymupdf.open() as doc:doc.new_page();doc.save(scan)
        with patch('importer.parser.ocr_page',return_value='Распознанный текст. '*30):
            self.assertTrue(extract_pages(scan)[0].used_ocr)
        with patch('importer.parser.ocr_page',side_effect=ImportFailure('Нет Tesseract')):
            self.assertEqual(extract_pages(scan)[0].issues,['Нет Tesseract'])
    def test_bulk_continues_after_failure(self):
        (self.path.parent/'second.pdf').write_bytes(b'bad')
        output=StringIO()
        with patch('textbooks.management.commands.import_all_textbooks.call_command',side_effect=[CommandError('Ошибка PDF'),None]) as call:
            with self.assertRaises(CommandError):call_command('import_all_textbooks',str(self.path.parent),stdout=output,stderr=StringIO())
        self.assertEqual(call.call_count,2)
