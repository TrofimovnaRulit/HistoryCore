#!/bin/zsh
set -e
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "Не найден Python 3. Установите его с python.org и запустите файл снова."
  read -r
  exit 1
fi
if [[ ! -x .venv/bin/python ]]; then
  echo "Первый запуск: создаю виртуальное окружение…"
  python3 -m venv .venv
  echo "Устанавливаю зависимости…"
  .venv/bin/python -m pip install -r requirements.txt
fi
if ! grep -q '^AI_API_KEY=[^[:space:]]' .env 2>/dev/null; then
  echo "В файле .env не указан AI_API_KEY. Вставьте новый ключ Gemini и запустите снова."
  read -r
  exit 1
fi
.venv/bin/python backend/manage.py migrate --noinput
.venv/bin/python backend/manage.py sync_json_catalog --source data --publish
PORT=8017
if command -v lsof >/dev/null 2>&1 && lsof -ti tcp:$PORT >/dev/null 2>&1; then
  PORT=8018
  echo "Порт 8017 уже занят, запускаю сайт на порту $PORT."
fi
open "http://127.0.0.1:$PORT/"
exec .venv/bin/python backend/manage.py runserver 127.0.0.1:$PORT
