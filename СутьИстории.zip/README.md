# СутьИстории — база учебников

Этот этап превращает уже существующие PDF учебников в проверяемые JSON-файлы. Исходные PDF не перемещаются, не скачиваются и не изменяются. SQL-база для подготовки каталога не нужна.

## Структура

```text
pdf/5/ … pdf/9/        исходные PDF (также поддерживаются папки «5 класс» … «9 класс»)
data/5/ … data/9/      отдельный JSON для каждого учебника
data/import-report.json итоговый отчёт
```

Каждый JSON содержит класс, метаданные учебника, разделы и параграфы. У параграфа сохраняются стабильный `id`, номер, название, страницы и полный серверный `text`. Текст не должен возвращаться публичному frontend API.

## Запуск

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python importer.py "/путь/к/pdf" --dry-run
python importer.py "/путь/к/pdf"
```

По умолчанию источник — `./pdf`, результат — `./data`. Для другого каталога:

```bash
python importer.py "/Users/artemdubrovskij/Desktop/web/СутьИстории/pdf" --output data
```

`--dry-run` читает и анализирует PDF, но не записывает JSON. При обычном запуске SHA-256 исходного PDF сохраняется в `textbook.source.sha256`; неизменившиеся файлы пропускаются. Для принудительной пересборки используйте `--force`.

## Извлечение и проверка

Используется PyMuPDF. Если текстового слоя недостаточно, парсер пытается применить Tesseract с русским языком. При отсутствии OCR или сомнительном результате файл получает статус `NEEDS_REVIEW`, но обработка остальных книг продолжается.

После запуска отчёт содержит число PDF, разделов, параграфов, проблемные страницы и статусы `OK`, `NEEDS_REVIEW` или `ERROR`. Проверка JSON:

```bash
python -m json.tool data/import-report.json >/dev/null
python - <<'PY'
import json
from pathlib import Path
files = [p for g in '56789' for p in (Path('data') / g).glob('*.json')]
ids = []
for path in files:
    book = json.loads(path.read_text(encoding='utf-8'))
    for section in book['sections']:
        for paragraph in section['paragraphs']:
            assert all(paragraph.get(k) not in (None, '', []) for k in ('id','number','title','pages','text'))
            ids.append(paragraph['id'])
assert len(ids) == len(set(ids))
print(f'{len(files)} файлов, {len(ids)} уникальных параграфов')
PY
```

Для OCR на macOS установите Tesseract и русский языковой пакет, затем повторите импорт:

```bash
brew install tesseract tesseract-lang
```

JSON является источником для следующего этапа HistoryCore: backend сможет найти параграф по `id`, взять закрытое поле `text` и передать его выбранному AI-провайдеру. Команда `sync_json_catalog` и Django-модели оставлены в проекте для будущего этапа подключения сайта, но этот pipeline сам SQL-базу не создаёт.
